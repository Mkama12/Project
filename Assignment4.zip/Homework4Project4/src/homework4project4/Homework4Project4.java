/*
This program accepts input sentence in which all of the words are run together 
but first character of each word is uppecase.
 */
package homework4project4;

import java.util.Scanner;

/**
 *
 * @author baimb
 */
public class Homework4Project4
{
    public static void main(String[] args)
    {
        // Create a Scanner object for keyboard input.
        Scanner keyboard = new Scanner(System.in);
        
        // Ask for user input
        System.out.println("Enter a Sentence:");
        String wordEntered = keyboard.nextLine();
        
        int index = 0;
        String wordOutput = "";
        
        // Loop to search for uppercase and convert it to lowercase and add space
        for(int i = 0; i < wordEntered.length(); i++)
        {
            if(Character.isUpperCase(wordEntered.charAt(i)) && index > 0)
            {   wordOutput += " ";
                wordOutput += Character.toLowerCase(wordEntered.charAt(i));
            }
            else
            {
                wordOutput += wordEntered.charAt(i);
            }
            
            index++;
        }
        
        // Displays output to the console
        System.out.println("Orignal sentence entered: " + wordEntered 
                            + "\nFormatted Sentence: " + wordOutput);
    }
    
}
