/*
The program creates a class that has three overloaded static methods 
for calculating the areas of circle, rectangle, and cylinder.
 */
package homework4project1;

/**
 *
 * @author baimb
 */
public class Area
{
    private static double areaOfShape;
    
    // Method to calculate the area of circles
    public static double getArea(double radius)
    {
        return areaOfShape = Math.PI * radius * radius;
    }
   
    // Method to calculate the area of rectangles
    public static double getArea(int length, int width)
    {
        return areaOfShape = length * width;
    }
   
    // Method to calculate the area of cylinders
    public static double getArea(double radius, int height)
    {
        return areaOfShape = Math.PI * radius * radius * height;
    }        
}
