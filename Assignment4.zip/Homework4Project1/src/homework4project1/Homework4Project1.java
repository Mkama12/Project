/*
This Program demonstrate the Area Class.
 */
package homework4project1;

/**
 *
 * @author baimb
 */
public class Homework4Project1
{
    public static void main(String[] args)
    {
        // Out of the areas calculation
        System.out.printf("The area of the circle is: %.2f\n", Area.getArea(20));
        System.out.printf("The area of the rectangle is: %.2f\n", Area.getArea(5, 10));
        System.out.printf("The area of the cylinder is: %.2f\n", Area.getArea(12, 15));        
    }
    
}
