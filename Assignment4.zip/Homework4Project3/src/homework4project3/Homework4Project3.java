/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package homework4project3;

import java.util.Scanner;

/**
 *
 * @author baimb
 */
public class Homework4Project3
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        // Create a Scanner object for keyboard input.
        Scanner keyboard = new Scanner(System.in);
        
        // Display company name. 
        System.out.println("Amazon password verifier");
        System.out.println("Please enter a password: ");  
        String password = keyboard.nextLine();
        
        VerifyPassword userPassword = new VerifyPassword(password);
        
        boolean validPassword = userPassword.isValid();

        System.out.println("The password of " + password + " is "
            + (validPassword ? " valid password " : " an invalid password"));
        
    }
    
}
