/*
This class verifies if a user password meet the following criteria
The password should be at least characters long
The password should contain at least one uppercase and at least one lowercase letter
The password should have at least one digit
 */
package homework4project3;

import java.util.function.Predicate;

/**
 *
 * @author baimb
 */
public class VerifyPassword
{
    private String userPassword;
    
    public VerifyPassword(String password)
    {
        userPassword = password;
    }
   
    public boolean isValid() 
    {   return hasUpperCase.and(hasLowerCase).and(hasLengthOfSix)
                .and(hasAtLeastOneDigit).test(this.userPassword);
    }
 

    Predicate<String> hasAtLeastOneDigit = new Predicate<String>() {
        @Override
        public boolean test(String t) {
            return t.chars().anyMatch(Character::isDigit);
        }
    };

    Predicate<String> hasLengthOfSix = new Predicate<String>() {
        @Override
        public boolean test(String t) {
            return t.length() >=6 ? true : false;
        }
    };

    Predicate<String> hasLowerCase = new Predicate<String>() {
        @Override
        public boolean test(String t) {
            return t.chars().anyMatch(Character::isLowerCase);
        }
    };

    Predicate<String> hasUpperCase = new Predicate<String>() 
    {
        @Override
        public boolean test(String t) {
            return t.chars().anyMatch(Character::isUpperCase);
        }  

    };
}