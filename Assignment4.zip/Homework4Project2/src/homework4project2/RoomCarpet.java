/*
RoomCarpet class that calculate the total price for the rectangle room carpeting
 */
package homework4project2;

/**
 *
 * @author baimb
 */
public class RoomCarpet
{
    private RoomDimension size;
    private double carpetCost;

    // Constructor for RoomCarpet class
    public RoomCarpet(RoomDimension dim, double price)
    {
        size = dim;
        carpetCost = price;
    }
    
    // Method to get the total cost of carpeting
    public double getTotalCost()
    {
        return size.getArea() * carpetCost;
    }
    
    /**
     *toString method
     * @return
     */
    @Override
    public String toString()
    {
        return "The total dimension of the room is " + size.getArea() 
                + " The total cost for carpeting the room is $" + getTotalCost();
    }
}
