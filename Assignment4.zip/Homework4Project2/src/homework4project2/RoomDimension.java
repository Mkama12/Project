/*
RoomDimension class that calculate the area of rectangle room
 */
package homework4project2;

/**
 *
 * @author baimb
 */
public class RoomDimension
{
    private double length;
    private double width;
   
    // Constructor for RoomDimension class
    public RoomDimension(double len, double w)
    {
        length = len;
        width = w;
    }
    
    // Method to calculate the area of the recangle room
    public double getArea()
    {
        return length * width;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString()
    {
        return "The length of the room is " + length + " and the width of the room is " 
                + width;
    }
}
