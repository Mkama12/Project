/*
This program calculate the price of carpeting of rectangular rooms for Westfield
Carpet company.
 */
package homework4project2;

import java.util.Scanner;

/**
 *
 * @author baimb
 */
public class Homework4Project2
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        // Create a Scanner object for keyboard input.
        Scanner keyboard = new Scanner(System.in);
        
        // Display company name. 
        System.out.println("Westfield Carpet Company");
        double length, width, carpetCost;

        // Get the length of the room.
        System.out.print("Enter the length of the room: ");
        length = keyboard.nextDouble();
       
        
        // Get the width of the room.
       
        System.out.print("Enter the width of the room: ");
        width = keyboard.nextDouble();
       
        
        // Get the cost of price per square feet of the desired carpeting.
       
        System.out.print("Enter the price per square feet for the desired carpeting: $");
        carpetCost = keyboard.nextDouble();
      

        // Create RoomDimension and RoomCarpet objects.
        RoomDimension dimensions = new RoomDimension(length, width);
        RoomCarpet roomCarpet = new RoomCarpet(dimensions, carpetCost);

        // Print the object calling the toString
        System.out.println(dimensions);
        System.out.println(roomCarpet);
    }
    
}
